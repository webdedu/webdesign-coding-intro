<ol class="comment-list">
  <?php wp_list_comments(); ?>
</ol>
<div>
  <?php comment_form(); ?>
</div>
