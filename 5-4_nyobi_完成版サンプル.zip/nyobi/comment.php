<ol class="comment-list">
  <?php wp_list_comments(); ?>
</ol>
<div class="comment-form">
  <?php comment_form(); ?>
</div>