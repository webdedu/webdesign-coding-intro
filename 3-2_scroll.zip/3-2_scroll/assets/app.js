$(function(){
  $("#btn").click(function(){
    $("h1")
      .text("ようこそ、N高のみなさん")
      .css("color","red");
  })
})