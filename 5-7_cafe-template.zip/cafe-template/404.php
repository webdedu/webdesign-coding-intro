<?php get_header(); ?>

<main>

<p>404</p>

</main>

<?php get_footer(); ?>